//! Browser surface for the code-talker ablation demo.
//!
//! Build with:
//!   wasm-pack build codetalker-wasm --target web --release

use codetalker_core::{aead, kem, session};
use serde::Serialize;
use wasm_bindgen::prelude::*;

#[derive(Serialize)]
pub struct Result_ {
    pub kem: String,
    pub is_pq: bool,
    pub suite: String,
    pub session_key: String,
    pub nonce: String,
    pub wire: String,
    pub wire_len: usize,
    pub recovered: Option<String>,
    pub broken: bool,
    pub verdict: String,
}

/// Run one transmission through the configured stack and report what an
/// adversary recovers.
#[wasm_bindgen]
pub fn transmit(
    plaintext: &str,
    backend: &str,
    key_agreement: bool,
    aead_on: bool,
    transport_on: bool,
    static_key: bool,
    nonce_reuse: bool,
    adversary_knows_transport: bool,
) -> std::result::Result<JsValue, JsValue> {
    let k = kem::backend(backend).map_err(|e| JsValue::from_str(&e.to_string()))?;

    let layers = session::Layers {
        key_agreement,
        aead: aead_on,
        transport: transport_on,
        static_key,
        nonce_reuse,
    };
    let suite = aead::Suite::Aes256Gcm;

    let t = session::transmit(&*k, layers, suite, plaintext.as_bytes())
        .map_err(|e| JsValue::from_str(&e.to_string()))?;
    let r = session::adversary(&t, layers, adversary_knows_transport)
        .map_err(|e| JsValue::from_str(&e.to_string()))?;

    let (recovered, verdict) = match &r {
        session::Recovery::Plaintext(p) => (
            Some(String::from_utf8_lossy(p).to_string()),
            "Plaintext recovered. The layer that failed was not the one on the outside.",
        ),
        session::Recovery::KeystreamReuse(_) => (
            None,
            "Nonce repeated, so the keystream repeated. A known crib recovers the rest by XOR.",
        ),
        session::Recovery::MetadataOnly => (
            None,
            "Length and timing only. Stripping the transport yields ciphertext, and ciphertext without the session key yields nothing.",
        ),
    };

    let out = Result_ {
        kem: k.name().to_string(),
        is_pq: k.is_pq(),
        suite: suite.name().to_string(),
        session_key: hex::encode(t.session_key),
        nonce: hex::encode(t.nonce),
        wire: hex::encode(&t.wire),
        wire_len: t.wire.len(),
        recovered,
        broken: r.is_broken(),
        verdict: verdict.to_string(),
    };
    serde_wasm_bindgen::to_value(&out).map_err(|e| JsValue::from_str(&e.to_string()))
}

/// Which KEM backends this build actually contains. The UI reads this rather
/// than assuming, so a missing feature shows up as absent instead of faked.
#[wasm_bindgen]
pub fn backends() -> Vec<JsValue> {
    ["static", "x25519", "xwing"]
        .iter()
        .filter(|n| kem::backend(n).is_ok())
        .map(|n| JsValue::from_str(n))
        .collect()
}
