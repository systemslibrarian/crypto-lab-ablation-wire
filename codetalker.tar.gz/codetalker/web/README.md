# web/

Static demo root. Everything here is served by GitHub Pages as-is.

- `index.html` — the demo shell
- `pkg/`       — wasm-pack output, generated in CI, not committed
- `.nojekyll`  — generated in CI; see the deploy job for why it matters

Nothing in this directory requires a server.
