//! The layered channel, with each layer independently switchable.
//!
//! The point of this crate is not to build a secure channel. It is to let a
//! reader turn layers off and observe precisely what an adversary gains.

use crate::aead::{self, Suite, NONCE_LEN};
use crate::error::Result;
use crate::handshake::{self, Handshake};
use crate::identity::Identity;
use crate::kem::Kem;
use crate::ratchet::Chain;
use rand_core::RngCore;

/// Which layers are engaged. Maps onto the 1942 stack, plus the two layers
/// that stack never had.
#[derive(Debug, Clone, Copy)]
pub struct Layers {
    /// L1 — key agreement. 1942: the pre-shared codebook.
    pub key_agreement: bool,
    /// L2 — authenticated encryption. 1942: homophonic substitution.
    pub aead: bool,
    /// L3 — transport obfuscation. 1942: a rare unwritten language.
    pub transport: bool,
    /// Peer authentication. 1942: absent entirely.
    pub authenticate: bool,
    /// Symmetric ratchet. 1942: absent entirely.
    pub ratchet: bool,
    /// Repeat the nonce. Catastrophic, and one of the demo scenarios.
    pub nonce_reuse: bool,
}

impl Default for Layers {
    fn default() -> Self {
        Layers {
            key_agreement: true,
            aead: true,
            transport: true,
            authenticate: true,
            ratchet: true,
            nonce_reuse: false,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Recovery {
    /// Full plaintext. The channel failed.
    Plaintext(Vec<u8>),
    /// Keystream recovered via repeated nonce; plaintext follows from a crib.
    KeystreamReuse(Vec<u8>),
    /// An active attacker completed a handshake with both sides.
    MachineInTheMiddle(Vec<u8>),
    /// Nothing but length and timing.
    MetadataOnly,
}

impl Recovery {
    pub fn is_broken(&self) -> bool {
        !matches!(self, Recovery::MetadataOnly)
    }
}

/// A live channel: a completed handshake plus its sending chain.
pub struct Channel {
    pub hs: Handshake,
    chain: Chain,
    suite: Suite,
    ratchet: bool,
}

pub struct Frame {
    pub wire: Vec<u8>,
    pub nonce: [u8; NONCE_LEN],
    pub message_key: [u8; 32],
    pub counter: u32,
}

pub const PAD_BLOCK: usize = 64;

impl Channel {
    pub fn new(hs: Handshake, suite: Suite, ratchet: bool) -> Self {
        let chain = Chain::new(hs.root);
        Channel { hs, chain, suite, ratchet }
    }

    /// Decrypt a frame from the peer.
    ///
    /// The receiving chain advances in lockstep with the sender's. If the two
    /// ever diverge, the message key is wrong and the tag rejects — which is
    /// the correct failure, not a bug to paper over.
    pub fn recv(&mut self, layers: Layers, frame: &Frame) -> Result<Vec<u8>> {
        let message_key = if self.ratchet { self.chain.next()? } else { self.chain.static_key()? };

        let body = if layers.transport {
            crate::transport::deobfuscate(&frame.wire)?
        } else {
            frame.wire.clone()
        };

        if !layers.aead {
            return Ok(body);
        }

        aead::open(self.suite, &message_key, &frame.nonce, &self.hs.transcript_hash, &body)
    }

    /// Encrypt one message. The transcript hash goes in as associated data, so
    /// a frame lifted from another session fails its tag check.
    pub fn send(&mut self, layers: Layers, plaintext: &[u8]) -> Result<Frame> {
        let message_key = if self.ratchet { self.chain.next()? } else { self.chain.static_key()? };
        let counter = self.chain.n;

        let mut nonce = [0u8; NONCE_LEN];
        if layers.nonce_reuse {
            nonce = [7u8; NONCE_LEN];
        } else {
            rand_core::OsRng.fill_bytes(&mut nonce);
        }

        let body = if layers.aead {
            aead::seal(self.suite, &message_key, &nonce, &self.hs.transcript_hash, plaintext)?
        } else {
            plaintext.to_vec()
        };

        let wire = if layers.transport {
            crate::transport::obfuscate(&body, PAD_BLOCK)
        } else {
            body
        };

        Ok(Frame { wire, nonce, message_key, counter })
    }
}

/// Establish a channel end to end, running both sides of a real handshake.
///
/// Returns the initiator's channel and the responder's, which must agree.
pub fn establish(
    kem: &dyn Kem,
    layers: Layers,
    suite: Suite,
) -> Result<(Channel, Channel)> {
    let identity = Identity::generate();
    let responder = handshake::Responder::new(kem, identity)?;
    let hello = responder.hello();
    let pinned = responder.identity_public();

    let (init_hs, reply) = handshake::initiate(
        kem,
        &hello,
        layers.authenticate,
        if layers.authenticate { Some(&pinned) } else { None },
    )?;
    let resp_hs = responder.accept(&reply, layers.authenticate)?;

    Ok((
        Channel::new(init_hs, suite, layers.ratchet),
        Channel::new(resp_hs, suite, layers.ratchet),
    ))
}

/// Model what an adversary recovers from one frame.
///
/// `adversary_knows_transport` is the Kieyoomia switch: it represents having a
/// linguist. Historically the Japanese had one and got nothing, because the
/// layer beneath was doing the work.
pub fn adversary(
    ch: &Channel,
    frame: &Frame,
    layers: Layers,
    adversary_knows_transport: bool,
) -> Result<Recovery> {
    // L3 is not a security boundary. Anyone who knows the scheme strips it.
    let body = if layers.transport {
        if !adversary_knows_transport {
            return Ok(Recovery::MetadataOnly);
        }
        crate::transport::deobfuscate(&frame.wire)?
    } else {
        frame.wire.clone()
    };

    if !layers.aead {
        // Obscurity only: the failure mode people mistake for the code talkers.
        return Ok(Recovery::Plaintext(body));
    }

    // No key agreement means the adversary holds the same fixed secret.
    if !layers.key_agreement {
        let pt = aead::open(
            ch.suite,
            &frame.message_key,
            &frame.nonce,
            &ch.hs.transcript_hash,
            &body,
        )?;
        return Ok(Recovery::Plaintext(pt));
    }

    if layers.nonce_reuse {
        return Ok(Recovery::KeystreamReuse(body));
    }

    Ok(Recovery::MetadataOnly)
}

/// Recover a plaintext from two ciphertexts sharing a key and nonce.
/// Returns P2 given C1, C2 and a crib for P1. Bounded by the crib's length.
pub fn two_time_pad(ct1: &[u8], ct2: &[u8], crib: &[u8]) -> Vec<u8> {
    let n = ct1.len().min(ct2.len()).min(crib.len());
    (0..n).map(|i| ct1[i] ^ ct2[i] ^ crib[i]).collect()
}
